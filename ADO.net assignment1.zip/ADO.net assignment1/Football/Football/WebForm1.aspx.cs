﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Football
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("data source =.; database =sample; integrated Security = SSPI");
            SqlCommand cmd = new SqlCommand("select WinningTeam,status  from FootballLeague WHERE Status ='Win';SELECT * FROM FootballLeague WHERE TeamName1 ='JAPAN' OR TeamName2 ='JAPAN';select WinningTeam, status  from FootballLeague WHERE Status = 'Draw';  ", con);
          
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            GridView1.DataSource = sdr;
            GridView1.DataBind();

            
            if(sdr.NextResult())
            {
                GridView2.DataSource = sdr;
                GridView2.DataBind();
            }
               
            
            if (sdr.NextResult())
            {
                
                GridView3.DataSource = sdr;
                GridView3.DataBind();
            }
            con.Close();
        }
    }
}