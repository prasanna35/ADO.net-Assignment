﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment2._1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("data source =.; database =sample; integrated Security = SSPI");
            SqlCommand cmd = new SqlCommand("Select BoardingPoint, TravelDate from BusInformation where Amount > 450;Select BusID, BoardingPoint,Rating from BusInformation where Rating > 3 ;Select BusID, DroppingPoint from BusInformation where TravelDate = '2017-12-10';  ", con);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();

            GridView1.DataSource = sdr;
            GridView1.DataBind();

            if (sdr.NextResult())
            {
                GridView2.DataSource = sdr;
                GridView2.DataBind();
            }

            if (sdr.NextResult())
            {
                GridView3.DataSource = sdr;
                GridView3.DataBind();
            }
            con.Close();

        }
    }
}